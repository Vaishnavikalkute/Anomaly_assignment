import joblib
import pandas as pd

clf = joblib.load('predict.pkl')

def predict_from_input():
    try:
        # User inputd
        feature1 = float(input("Enter value for feature1: "))
        feature2 = float(input("Enter value for feature2: "))
        
        
        input_data = pd.DataFrame({
            'feature1': [feature1],
            'feature2': [feature2]
        })

        # prediction
        prediction = clf.predict(input_data)

        # result
        if prediction[0] == -1:
            print("The specific data point is classified as an Anomaly.")
        else:
            print("The specific data point is classified as Normal.")
    
    except ValueError:
        print("Please enter valid numerical values for the features.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Run the prediction function
predict_from_input()
