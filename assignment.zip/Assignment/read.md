Install requirments 
""
    pip install -r requirements.txt 
""

To test the model you can run test.py file
""
python3 test.py
""